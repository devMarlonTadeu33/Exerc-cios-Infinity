import mysql.connector as mysql


conn = mysql.connect(
    host='roo27.h.filess.io',
    port=61002,
    user='testdb_skinskinit',
    password='21b3f71f7ce8420cc37c28e53a0f30e97e592ab5',
    database='testdb_skinskinit'
)

